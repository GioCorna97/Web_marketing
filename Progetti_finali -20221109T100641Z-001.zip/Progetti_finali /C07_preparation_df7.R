#### FIRST LOOK of df_7 ####
df_7_tic = raw_7_tic 
str(df_7_tic)
summary(df_7_tic)

#### START CLEANING df_7 ####

df_7_tic_clean <- df_7_tic

#### CLEANING DATA TYPES in df_7 ####

## formatting dates and times ##
df_7_tic_clean <- df_7_tic_clean %>%
  mutate(TIC_DATETIME = as.POSIXct(DATETIME, format="%Y-%m-%dT%H%M%S")) %>%
  mutate(TIC_HOUR = hour(TIC_DATETIME)) %>%
  mutate(TIC_DATE = as.Date(TIC_DATETIME)) %>%
  select(-DATETIME) %>%
  mutate(ID_SCONTRINO = as.character(ID_SCONTRINO)) %>%
  mutate(ID_CLI = as.character(ID_CLI)) %>%
  mutate(ID_NEG = as.character(ID_NEG)) %>%
  mutate(ID_ARTICOLO = as.character(ID_ARTICOLO))

## formatting boolean as factor ##
df_7_tic_clean <- df_7_tic_clean %>%
  mutate(DIREZIONE = as.factor(DIREZIONE))

## formatting numerical categories as factor ##
df_7_tic_clean <- df_7_tic_clean %>%
  mutate(COD_REPARTO = as.factor(COD_REPARTO))

#### CONSISTENCY CHECK ID_CLI in df_1/df_7 ####

cons_idcli_df1_df7 <- df_1_cli_fid_clean %>%
  select(ID_CLI) %>%
  distinct() %>%
  mutate(is_in_df_1 = 1) %>%
  distinct() %>%
  full_join(df_7_tic_clean %>%
              select(ID_CLI) %>%
              distinct() %>%
              mutate(is_in_df_7 = 1) %>%
              distinct()
            , by = "ID_CLI"
  ) %>%
  group_by(is_in_df_1, is_in_df_7) %>%
  summarize(NUM_ID_CLIs = n_distinct(ID_CLI)) %>%
  as.data.frame()

cons_idcli_df1_df7

#!!! NOTE: all ID_CLI in df_7 are mapped in df_1, but not all ID_CLI in df_1 are mapped in df_7 !!!#  

#### RESHAPING df_7 ####

df_7_tic_clean_final <- df_7_tic_clean %>%
  ## adding day characterization ##
  mutate(TIC_DATE_WEEKDAY = wday(TIC_DATE, week_start=1)) %>%
  mutate(TIC_DATE_HOLIDAY = isHoliday("Italy", TIC_DATE)) %>%
  mutate(TIC_DATE_TYP = case_when(
    (TIC_DATE_WEEKDAY %in% c(6,7)) ~ "weekend"
    , (TIC_DATE_HOLIDAY == TRUE) ~ "holiday"
    , (TIC_DATE_WEEKDAY < 6) ~ "weekday"
    , TRUE ~ "other"
    )
  )

#### EXPLORE VARIABLES in df_7 ####

### GENERAL OVERVIEW ###

## compute aggregate
df7_overview <- df_7_tic_clean_final %>% 
  summarize(MIN_DATE = min(TIC_DATE)
            , MAX_DATE = max(TIC_DATE)
            , TOT_TICs = n_distinct(ID_SCONTRINO)
            , TOT_CLIs = n_distinct(ID_CLI))

df7_overview

### Variable DIREZIONE ###

## compute aggregate
df7_dist_direction <- df_7_tic_clean_final %>%
  group_by(DIREZIONE) %>%
  summarize(TOT_TICs = n_distinct(ID_SCONTRINO)
            , TOT_CLIs = n_distinct(ID_CLI)) %>%
  mutate(PERCENT_TICs = TOT_TICs/df7_overview$TOT_TICs
         , PERCENT_CLIs = TOT_CLIs/df7_overview$TOT_CLIs)

df7_dist_direction

### Variable TIC_HOURS ###

## compute aggregate
df7_dist_hour <- df_7_tic_clean_final %>%
  group_by(TIC_HOUR, DIREZIONE) %>%
  summarize(TOT_TICs = n_distinct(ID_SCONTRINO)
            , TOT_CLIs = n_distinct(ID_CLI)) %>%
  left_join(df7_dist_direction %>%
              select(DIREZIONE
                     , ALL_TOT_TICs = TOT_TICs
                     , ALL_TOT_CLIs = TOT_CLIs)
            , by = 'DIREZIONE'
  ) %>%
  mutate(PERCENT_TICs = TOT_TICs/ALL_TOT_TICs
         , PERCENT_CLIs = TOT_CLIs/ALL_TOT_CLIs) %>%
  select(-ALL_TOT_TICs, -ALL_TOT_CLIs)

df7_dist_hour

## plot aggregate
plot_df7_dist_hour <- (
  ggplot(data=df7_dist_hour
         , aes(fill=DIREZIONE, x=TIC_HOUR, y=TOT_TICs)) +
    geom_bar(stat="identity") +
    labs(y="Totale Transazioni", x = "Orario di Acquisto") + 
    #geom_smooth(method = "lm") +
    theme_minimal()
)

plot_df7_dist_hour

## plot aggregate percent
plot_df7_dist_hour_percent <- (
  ggplot(data=df7_dist_hour
         , aes(fill=DIREZIONE, x=TIC_HOUR, y=TOT_TICs)) +
    geom_bar(stat="identity", position="fill" ) +
    theme_minimal()
)

plot_df7_dist_hour_percent


### Variable COD_REPARTO ###

## compute aggregate
df7_dist_dep <- df_7_tic_clean_final %>%
  group_by(COD_REPARTO, DIREZIONE) %>%
  summarize(TOT_TICs = n_distinct(ID_SCONTRINO)
            , TOT_CLIs = n_distinct(ID_CLI)) %>%
  left_join(df7_dist_direction %>%
              select(DIREZIONE
                     , ALL_TOT_TICs = TOT_TICs
                     , ALL_TOT_CLIs = TOT_CLIs)
            , by = 'DIREZIONE'
            ) %>%
  mutate(PERCENT_TICs = TOT_TICs/ALL_TOT_TICs
         , PERCENT_CLIs = TOT_CLIs/ALL_TOT_CLIs) %>%
    select(-ALL_TOT_TICs, -ALL_TOT_CLIs)
    
df7_dist_dep

## plot aggregate
plot_df7_dist_dep <- (
  ggplot(data=df7_dist_dep
         , aes(fill=DIREZIONE, x=COD_REPARTO, y=TOT_TICs)) +
    geom_bar(stat="identity") +
    theme_minimal()
)

plot_df7_dist_dep

## plot aggregate percent
plot_df7_dist_dep_percent <- (
  ggplot(data=df7_dist_dep
         , aes(fill=DIREZIONE, x=COD_REPARTO, y=TOT_TICs)) +
    geom_bar(stat="identity", position="fill" ) +
    theme_minimal()
)

plot_df7_dist_dep_percent

### Variable TIC_DATE_TYP ###

## compute aggregate
df7_dist_datetyp <- df_7_tic_clean_final %>%
  group_by(TIC_DATE_TYP, DIREZIONE) %>%
  summarize(TOT_TICs = n_distinct(ID_SCONTRINO)
            , TOT_CLIs = n_distinct(ID_CLI)) %>%
  left_join(df7_dist_direction %>%
              select(DIREZIONE
                     , ALL_TOT_TICs = TOT_TICs
                     , ALL_TOT_CLIs = TOT_CLIs)
            , by = 'DIREZIONE'
  ) %>%
  mutate(PERCENT_TICs = TOT_TICs/ALL_TOT_TICs
         , PERCENT_CLIs = TOT_CLIs/ALL_TOT_CLIs) %>%
  select(-ALL_TOT_TICs, -ALL_TOT_CLIs)

df7_dist_datetyp

## plot aggregate
plot_df7_dist_datetyp <- (
  ggplot(data=df7_dist_datetyp
         , aes(fill=DIREZIONE, x=TIC_DATE_TYP, y=TOT_TICs)) +
    labs(y="Totale Transazioni", x = "Tipo di Data") +
    geom_bar(stat="identity") +
    theme_minimal()
)

plot_df7_dist_datetyp

## plot aggregate percent
plot_df7_dist_datetyp_percent <- (
  ggplot(data=df7_dist_datetyp
         , aes(fill=DIREZIONE, x=TIC_DATE_TYP, y=TOT_TICs)) +
    geom_bar(stat="identity", position="fill" ) +
    theme_minimal()
)

plot_df7_dist_datetyp_percent

### Variable average IMPORTO_LORDO and average SCONTO per TICKET ###

## compute aggregate
df7_dist_importosconto <- df_7_tic_clean_final %>%
  group_by(ID_SCONTRINO, DIREZIONE) %>%
  summarize(IMPORTO_LORDO = sum(IMPORTO_LORDO)
            , SCONTO = sum(SCONTO)) %>%
  ungroup() %>%
  as.data.frame()

df7_dist_avgimportosconto <- df7_dist_importosconto %>%
  group_by(DIREZIONE) %>%
  summarize(AVG_IMPORTO_LORDO = mean(IMPORTO_LORDO)
            , AVG_SCONTO = mean(SCONTO))

df7_dist_avgimportosconto

## plot aggregate
plot_df7_dist_importo <- (
  ggplot(data=df7_dist_importosconto %>%
           filter((IMPORTO_LORDO > -1000) & (IMPORTO_LORDO < 1000))
         , aes(color=DIREZIONE, x=IMPORTO_LORDO)) +
    geom_histogram(binwidth=10, fill="white", alpha=0.5) +
    theme_minimal()
)

plot_df7_dist_importo

## plot aggregate
plot_df7_dist_sconto <- (
  ggplot(data=df7_dist_importosconto %>%
           filter((SCONTO > -250) & (IMPORTO_LORDO < 250))
         , aes(color=DIREZIONE, x=SCONTO)) +
    geom_histogram(binwidth=10, fill="white", alpha=0.5) +
    theme_minimal()
)

plot_df7_dist_sconto

#### ???? TO DO df_7 ???? ####

# EXPLORE average IMPORTO_LORDO and average SCONTO by COD_REPARTO

## compute distribution of the variable IMPORTO_LORDO and SCONTO by COD_REPARTO
df7_dist_importosconto_cod_rep <- df_7_tic_clean_final %>%
  group_by(COD_REPARTO, DIREZIONE) %>%
  summarise(AVG_IMPORTO_LORDO = mean(IMPORTO_LORDO)
            , AVG_SCONTO = mean(SCONTO)) %>%
  ungroup() %>%
  as.data.frame()
df7_dist_importosconto_cod_rep 


## plot distribution of the variable IMPORTO_LORDO by COD_REPARTO
ggplot(data=df7_dist_importosconto_cod_rep,
       aes(fill = DIREZIONE,
           x = COD_REPARTO,
           y = AVG_IMPORTO_LORDO)) + 
  geom_bar(stat = "identity") +   
  theme_minimal()


## plot distribution of the variable SCONTO by COD_REPARTO

ggplot(data=df7_dist_importosconto_cod_rep,
       aes(fill = DIREZIONE,
           x = COD_REPARTO,
           y = AVG_SCONTO)) + 
  geom_bar(stat = "identity") +   
  theme_minimal()




# EXPLORE ID_ARTICOLO DISTRIBUTIONS (i.e. num TICs by ID_ARTICOLO)
df_7_tic_clean_final$ID_ARTICOLO <- as.factor(df_7_tic_clean_final$ID_ARTICOLO)

## compute distribution of the variable NUM_VENDITE by ID_ARTICOLO
df7_dist_id_articolo <- df_7_tic_clean_final        %>%
  filter(DIREZIONE == 1)                            %>% 
  group_by(ID_ARTICOLO)                             %>% 
  summarise(NUM_VENDITE = n_distinct(ID_SCONTRINO)) %>% 
  ungroup()                                         %>%
  as.data.frame()                                   %>%
  arrange(desc(NUM_VENDITE))

df7_dist_id_articolo

## plot distribution of the variable NUM_VENDITE by ID_ARTICOLO

ggplot(data=df7_dist_id_articolo
       , aes(x=NUM_VENDITE)) +
  geom_histogram(binwidth=5, alpha=0.5) +
  theme_minimal()

## plot distribution of the variable NUM_VENDITE by ID_ARTICOLO (enhanced visibility)

ggplot(data=df7_dist_id_articolo %>%
         filter(NUM_VENDITE < 300) # to enhance visibility 
       , aes(x=NUM_VENDITE)) +
  geom_histogram(binwidth=5, alpha=0.5) +
  theme_minimal()


# EXPLORE average IMPORTO_LORDO and average SCONTO per ID_CLI
## compute the AVG IMPORTO_LORDO and SCONTO by ID_CLI
df7_dist_importosconto_id_cli <- df_7_tic_clean_final %>%
  filter(DIREZIONE == 1) %>%
  group_by(ID_CLI) %>%
  summarise(AVG_IMPORTO_LORDO = round(mean(IMPORTO_LORDO),2)
            , AVG_SCONTO = round(mean(SCONTO),2)) %>%
  ungroup() %>%
  as.data.frame() %>% 
  arrange(desc(AVG_IMPORTO_LORDO))

df7_dist_importosconto_id_cli

## compute average IMPORTO_LORDO and average SCONTO (overall)
df7_dist_avgimportosconto_id_cli <- df7_dist_importosconto_id_cli%>%
  summarise(AVG_IMPORTO_LORDO =  round(mean(mean(AVG_IMPORTO_LORDO)),2)
            , AVG_SCONTO =  round(mean(mean(AVG_SCONTO)),2))

df7_dist_avgimportosconto_id_cli

## plot distribution of the variable IMPORTO_LORDO by number n_cli
ggplot(data=df7_dist_importosconto_id_cli %>%
           filter((AVG_IMPORTO_LORDO < 1000))
         , aes(x=AVG_IMPORTO_LORDO)) +
    geom_histogram(binwidth=50, alpha=0.5) +
    ylab("num_clienti")+
    theme_minimal()

## plot distribution of the variable SCONTO by ID_CLI

ggplot(data=df7_dist_importosconto_id_cli %>%
         filter((AVG_SCONTO < 250))
       , aes(x=AVG_SCONTO)) +
  geom_histogram(binwidth=10, alpha=0.5) +
  ylab("num_clienti")+
  theme_minimal()

# compute the distribution of customers by number of purchases
df7_dist_tics_per_cli <- df_7_tic_clean_final %>%
  filter(DIREZIONE == 1)  %>% 
  group_by(ID_CLI) %>%
  summarise(TOT_TICs=n_distinct(ID_SCONTRINO)) %>% 
  ungroup() %>% 
  group_by(TOT_TICs) %>% 
  summarise(TOT_CLIs=n_distinct(ID_CLI)) %>%
  arrange(TOT_TICs) %>% 
  ungroup() %>%
  mutate(PERCENT_COVERED = cumsum(TOT_CLIs)/sum(TOT_CLIs)) %>% 
  as.data.frame()

df7_dist_tics_per_cli


ggplot(data=df7_dist_tics_per_cli %>% 
         filter((TOT_TICs<11))
       ,aes(x=TOT_TICs, y=TOT_CLIs)) +
  geom_bar(stat="identity") +
  theme_minimal()

# compute the days for next purchase curve (as described in the slides)

## compute the purchase count per client
df7_dist_tot_purch <- df_7_tic_clean_final           %>%
  filter(DIREZIONE == 1)                             %>% 
  group_by(ID_CLI)                                   %>% 
  summarise(TOT_PURCHASE = n_distinct(ID_SCONTRINO)) %>% 
  arrange(desc(TOT_PURCHASE)) 

df7_dist_tot_purch

##Days for Next Purchase Curve
data_for_next_purchase <- df_7_tic_clean_final %>%
  filter(DIREZIONE == 1) %>% 
  select(ID_SCONTRINO,
         ID_CLI,
         ID_ARTICOLO,
         TIC_DATE)  %>% 
  arrange(ID_CLI)

data_for_next_purchase

## compute days per client between the first and the second purchase

df_np_with_lag <- data_for_next_purchase %>% 
  group_by(ID_CLI) %>%
  arrange(TIC_DATE, .by_group = TRUE) %>%
  filter(row_number() <= 2) %>%
  mutate(LAGGED_DATE = lag(TIC_DATE)) %>%
  filter(!is.na(LAGGED_DATE)) %>%
  ungroup() %>%
  as.data.frame()

df_np = df_np_with_lag %>%
  mutate(DIFF = difftime(TIC_DATE, LAGGED_DATE, units = "days")) %>%
  select(-LAGGED_DATE)

df_np$ID_ARTICOLO <- as.factor(df_np$ID_ARTICOLO)

## compute distribution of days between purchases per client
x <- as.data.frame(table(df_np$DIFF))
x <- x[-1, ] #remove purchases made on the same day


x$Perc <- x$Freq/sum(x$Freq)
x$Perc_cum <- cumsum(x$Perc)
ggplot(x, 
       aes(x = as.numeric(Var1),
           y = cumsum(Perc))) +
  labs(title = "Next Purchase Curve",
       x = "Last Purchase Date (in Days)",
       y = "Cumulative Percent") +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.6)) +   
  scale_x_continuous(breaks = seq(0, 400, 25)) +  
  ylim(0,1) +
  geom_line(size = 1)

#### FINAL REVIEW df_7_clean ####

str(df_7_tic_clean_final)
summary(df_7_tic_clean_final)

#### REMOVAL OF INTERMEDIATE DATASETS

'''
rm(cons_idcli_df1_df7)
rm(df_7_tic)
rm(df_7_tic_clean)
rm(df7_dist_avgimportosconto)
rm(df7_dist_avgimportosconto_id_cli)
rm(df7_dist_datetyp)
rm(df7_dist_dep)
rm(df7_dist_direction)
rm(df7_dist_hour)
rm(df7_dist_id_articolo)
rm(df7_dist_importosconto)
rm(df7_dist_importosconto_cod_rep)
rm(df7_dist_importosconto_id_cli)
rm(df7_overview)
rm(plot_df7_dist_datetyp)
rm(plot_df7_dist_datetyp_percent)
rm(plot_df7_dist_dep)
rm(plot_df7_dist_dep_percent)
rm(plot_df7_dist_hour)
rm(plot_df7_dist_hour_percent)
rm(plot_df7_dist_importo)
rm(plot_df7_dist_sconto)
rm(df7_dist_tics_per_cli)
rm(df7_dist_tot_purch)
rm(data_for_next_purchase)
rm(df_np_with_lag)
rm(df_np)
rm(x)
'''
